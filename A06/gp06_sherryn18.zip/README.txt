Welcome to NLS Image Compression 101!

To begin, ensure that your computer is equipped with the latest version of Python,
and the following libraries are installed:
-OpenCV
-Numpy

To compress desired images, simply dump the images into the input folder, and double click "compress.bat".
The images will then be compressed and dumped into the output folder.

To decompress desired .nls files, ensure they are in the output folder, and double click "decompress.bat".

Ta-Da! You're all set!

Thank you for using NLS Image Compression!

